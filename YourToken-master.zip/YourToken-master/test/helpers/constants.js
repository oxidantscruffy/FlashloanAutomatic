module.exports = {
  TEST_MNEMONIC_PHRASE:
    'dice shove sheriff police boss indoor hospital vivid tenant method game matter',
};
