# Certora specifications

Certora specification files appear in this directory (`specs`), while harnesses are under `harnesses` and run scripts of the Certora Prover are in `scripts`. The run scripts are designed to run from within project root directory.

## Fountain
Run `applyHarnesses.sh` firsh and checked using `fountain.spec`.

## YourToken
Run `applyHarnesses.sh` firsh and checked using `YourToken.spec`.
